## Menambahkan dependensi validator 
 ``` bash
 go get github.com/go-playground/validator/v10

```
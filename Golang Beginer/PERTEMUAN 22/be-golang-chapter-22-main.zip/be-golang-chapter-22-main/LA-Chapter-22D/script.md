### test xss cross site scripting

``` javascript
<script>alert('Your session has been hijacked!');</script>

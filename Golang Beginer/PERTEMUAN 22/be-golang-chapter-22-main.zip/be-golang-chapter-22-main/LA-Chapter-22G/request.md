### test request server

``` bash
curl -H "Authorization: token_valid" http://localhost:8080/protected
